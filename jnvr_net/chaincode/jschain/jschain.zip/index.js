'use strict'

const jschain = require('./lib/jschain');
module.exports.jschain=jschain;
module.exports.contracts=[jschain];
